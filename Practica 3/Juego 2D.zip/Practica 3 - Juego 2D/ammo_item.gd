extends Area2D

@export var ammo_to_give: int = 2 # Cantidad de balas que recarga

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	area_entered.connect(_on_area_entered)

func _on_body_entered(body: Node2D) -> void:
	_collect(body)

func _on_area_entered(area: Area2D) -> void:
	_collect(area)

func _collect(entity: Node2D) -> void:
	if entity.has_method("add_ammo"):
		entity.add_ammo(ammo_to_give)
		queue_free()

extends CPUParticles2D

func _ready() -> void:
	z_index = 20
	emitting = true
	if has_node("HitSound"):
		$HitSound.pitch_scale = randf_range(0.85, 1.15)
		$HitSound.play()
		
	var audio_length = 0.0
	if has_node("HitSound") and $HitSound.stream:
		audio_length = $HitSound.stream.get_length()

	var wait_time = max(lifetime + 0.1, audio_length)
	await get_tree().create_timer(wait_time).timeout
	queue_free()

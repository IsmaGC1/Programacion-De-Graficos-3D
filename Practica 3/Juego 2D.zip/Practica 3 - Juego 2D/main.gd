extends Node

@export var ammo_item_scene: PackedScene = preload("res://ammo_item.tscn")
@export var mob_scene: PackedScene
@onready var camera_default_pos: Vector2 = $Camera2D.position

var score = 0

func _ready():
	Input.mouse_mode = Input.MOUSE_MODE_HIDDEN
	$Player.ammo_changed.connect($HUD.update_ammo)
	$Player.shot_fired.connect(shake_camera)
	$Player.empty_shot.connect($HUD.flash_empty_ammo)
	
func game_over():
	$ScoreTimer.stop()
	$MobTimer.stop()
	$HUD.show_game_over()
	$HUD.show_death_fade()
	$Music.stop()
	$DeathSound.play()
	$AmmoTimer.stop()
	get_tree().call_group("ammo_items", "queue_free")

func new_game():
	score = 0
	$HUD.update_score(score)
	$HUD.update_ammo($Player.current_ammo)
	$HUD.show_message("Get Ready")
	$Player.start($StartPosition.position)
	$StartTimer.start()
	get_tree().call_group("mobs", "queue_free")
	get_tree().call_group("ammo_items", "queue_free")
	$AmmoTimer.start()
	$MobTimer.wait_time = 0.5

func _on_mob_timer_timeout() -> void:
	var mob = mob_scene.instantiate()
	var mob_spawn_location = $MobPath/MobSpawnLocation
	mob_spawn_location.progress_ratio = randf()
	mob.position = mob_spawn_location.position
	var direction = mob_spawn_location.rotation + PI / 2
	direction += randf_range(-PI / 4, PI / 4)
	mob.rotation = direction
	var velocity = Vector2(randf_range(150.0, 250.0), 0.0)
	mob.linear_velocity = velocity.rotated(direction)
	add_child(mob)

func _on_ammo_timer_timeout():
	var item = ammo_item_scene.instantiate()
	item.add_to_group("ammo_items")
	var screen_size = get_viewport().get_visible_rect().size
	item.position = Vector2(
		randf_range(50.0, screen_size.x - 50.0),
		randf_range(50.0, screen_size.y - 50.0)
	)
	add_child(item)

func _on_score_timer_timeout() -> void:
	score += 1
	$HUD.update_score(score)
	if score % 15 == 0 and $MobTimer.wait_time > 0.2:
		$MobTimer.wait_time = max(0.2, $MobTimer.wait_time - 0.1)

func _on_start_timer_timeout() -> void:
	$MobTimer.start()
	$ScoreTimer.start()
	$Music.play()

func _on_hud_start_game() -> void:
	new_game()

func shake_camera(intensity: float = 3.0, duration: float = 0.1) -> void:
	var tween = create_tween()
	var steps = int(duration / 0.02)
	for i in range(steps):
		var offset = Vector2(randf_range(-intensity, intensity), randf_range(-intensity, intensity))
		tween.tween_property($Camera2D, "position", camera_default_pos + offset, 0.02)
	tween.tween_property($Camera2D, "position", camera_default_pos, 0.02)

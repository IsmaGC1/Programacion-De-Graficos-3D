extends Area2D

signal hit
signal ammo_changed(new_ammo: int)
signal shot_fired
signal empty_shot

@export var speed: int = 400
@export var bullet_scene: PackedScene = preload("res://bullet.tscn")
@onready var shoot_timer: Timer = $ShootTimer
@onready var muzzle_flash: Sprite2D = $Muzzle/Flash

var screen_size: Vector2
const MAX_AMMO: int = 4
var current_ammo: int = MAX_AMMO

func _ready() -> void:
	screen_size = get_viewport_rect().size
	hide()

func _process(delta: float) -> void:
	var velocity = Vector2.ZERO
	if Input.is_action_pressed("move_right"):
		velocity.x += 1
	if Input.is_action_pressed("move_left"):
		velocity.x -= 1
	if Input.is_action_pressed("move_down"):
		velocity.y += 1
	if Input.is_action_pressed("move_up"):
		velocity.y -= 1

	if velocity.length() > 0:
		velocity = velocity.normalized() * speed
		$AnimatedSprite2D.play()
	else:
		$AnimatedSprite2D.stop()

	position += velocity * delta
	position = position.clamp(Vector2.ZERO, screen_size)

	if velocity.x != 0:
		$AnimatedSprite2D.animation = "walk"
		$AnimatedSprite2D.flip_v = false
		$AnimatedSprite2D.flip_h = velocity.x < 0
	elif velocity.y != 0:
		$AnimatedSprite2D.animation = "up"
		$AnimatedSprite2D.flip_v = velocity.y > 0

	if Input.is_action_just_pressed("shoot"):
		shoot()

func shoot() -> void:
	if not is_visible() or not shoot_timer.is_stopped():
		return

	if current_ammo <= 0:
		$EmptyClickSound.pitch_scale = randf_range(0.95, 1.05)
		$EmptyClickSound.play()
		empty_shot.emit()
		shoot_timer.start()
		return

	current_ammo -= 1
	ammo_changed.emit(current_ammo)
	shoot_timer.start()

	$ShootSound.pitch_scale = randf_range(0.92, 1.08)
	$ShootSound.play()
	shot_fired.emit()
	_play_muzzle_flash()

	var bullet = bullet_scene.instantiate()
	bullet.global_position = global_position
	bullet.rotation = (get_global_mouse_position() - global_position).angle()
	get_tree().current_scene.add_child(bullet)

func add_ammo(amount: int) -> void:
	current_ammo += amount
	ammo_changed.emit(current_ammo)
	$PickupSound.pitch_scale = randf_range(0.95, 1.15)
	$PickupSound.play()

func start(pos: Vector2) -> void:
	position = pos
	show()
	$CollisionShape2D.disabled = false
	current_ammo = MAX_AMMO
	ammo_changed.emit(current_ammo)

func _on_body_entered(_body: Node2D) -> void:
	hide()
	hit.emit()
	$CollisionShape2D.set_deferred("disabled", true)

func _play_muzzle_flash() -> void:
	muzzle_flash.visible = true
	muzzle_flash.modulate.a = 1.0
	muzzle_flash.scale = Vector2(1.5, 1.5)
	muzzle_flash.rotation = randf_range(-PI, PI)
	var tween = create_tween()
	tween.tween_property(muzzle_flash, "scale", Vector2(3.8, 3.8), 1)
	tween.parallel().tween_property(muzzle_flash, "modulate:a", 0.0, 0.08)
	tween.tween_callback(func(): muzzle_flash.visible = false)

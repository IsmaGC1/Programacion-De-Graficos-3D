extends Area2D

@export var speed: float = 600.0

var death_particles_scene: PackedScene = preload("res://enemy_death_particles.tscn")

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	area_entered.connect(_on_area_entered)
	$VisibleOnScreenNotifier2D.screen_exited.connect(_on_screen_exited)

func _physics_process(delta: float) -> void:
	position += transform.x * speed * delta

func _spawn_particles_and_kill(target: Node2D) -> void:
	var particles = death_particles_scene.instantiate()
	particles.global_position = target.global_position
	particles.rotation = rotation
	get_tree().current_scene.add_child(particles)
	target.queue_free()
	queue_free()

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("mobs"):
		_spawn_particles_and_kill(body)

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("mobs"):
		_spawn_particles_and_kill(area)

func _on_screen_exited() -> void:
	queue_free()

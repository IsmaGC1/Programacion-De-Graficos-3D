extends CanvasLayer

@onready var start_button: Button = $StartButton
@onready var controls_button: Button = $ControlsButton
@onready var controls_panel: Panel = $ControlsPanel

signal start_game

var pulse_tween: Tween

func _ready() -> void:
	start_button.mouse_entered.connect(_on_start_button_mouse_entered)
	start_button.mouse_exited.connect(_on_start_button_mouse_exited)
	await get_tree().process_frame
	start_button.pivot_offset = start_button.size / 2.0
	start_button_pulse()

func update_score(score: int) -> void:
	$ScoreLabel.text = "Time: " + str(score)

func update_ammo(ammo: int) -> void:
	$AmmoLabel.text = str(ammo) + " x"

func show_message(text: String) -> void:
	$Message.text = text
	$Message.show()
	$MessageTimer.start()

func show_game_over() -> void:
	show_message("Game Over")
	await $MessageTimer.timeout
	$Message.text = "Dodge And Kill\nTo Survive!"
	$Message.show()
	await get_tree().create_timer(1.0).timeout
	controls_button.show()
	start_button_pulse()

func start_button_pulse() -> void:
	start_button.show()
	if pulse_tween and pulse_tween.is_valid():
		pulse_tween.kill()

	pulse_tween = create_tween().set_loops()
	pulse_tween.tween_property(start_button, "scale", Vector2(1.08, 1.08), 0.6).set_trans(Tween.TRANS_SINE)
	pulse_tween.tween_property(start_button, "scale", Vector2(1.0, 1.0), 0.6).set_trans(Tween.TRANS_SINE)

func _on_start_button_pressed() -> void:
	if pulse_tween and pulse_tween.is_valid():
		pulse_tween.kill()
	
	start_button.scale = Vector2.ONE
	start_button.hide()
	controls_panel.hide()
	controls_button.hide()
	$ButtonSound.play()
	reset_death_fade()
	start_game.emit()

func _on_message_timer_timeout() -> void:
	$Message.hide()

func show_death_fade() -> void:
	var tween = create_tween()
	tween.tween_property($DeathOverlay, "modulate:a", 0.6, 0.5)

func reset_death_fade() -> void:
	$DeathOverlay.modulate.a = 0.0

func flash_empty_ammo() -> void:
	var tween = create_tween()
	tween.tween_property($AmmoLabel, "modulate", Color.RED, 0.08)
	tween.tween_property($AmmoLabel, "modulate", Color.WHITE, 0.08)
	tween.tween_property($AmmoLabel, "modulate", Color.RED, 0.08)
	tween.tween_property($AmmoLabel, "modulate", Color.WHITE, 0.08)

func _on_start_button_mouse_entered() -> void:
	if pulse_tween and pulse_tween.is_valid():
		pulse_tween.kill()
		
	var tween = create_tween()
	tween.tween_property(start_button, "scale", Vector2(1.12, 1.12), 0.1)

func _on_start_button_mouse_exited() -> void:
	if start_button.visible:
		start_button_pulse()

func _on_controls_button_pressed() -> void:
	controls_button.release_focus()
	controls_panel.visible = !controls_panel.visible
	if controls_panel.visible:
		start_button.disabled = true
	else:
		start_button.disabled = false

func _on_close_controls_button_pressed() -> void:
	controls_panel.hide()
	start_button.disabled = false # Reorganizar el botón de Start

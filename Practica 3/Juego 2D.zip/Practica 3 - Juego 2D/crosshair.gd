extends Node2D

@export var color: Color = Color(1.0, 0.2, 0.2, 0.9) # Rojo suave visible
@export var line_length: float = 6.0
@export var gap: float = 3.0
@export var line_width: float = 1.5

func _draw() -> void:
	draw_circle(Vector2.ZERO, 1.5, color)
	draw_line(Vector2(0, -gap), Vector2(0, -gap - line_length), color, line_width)
	draw_line(Vector2(0, gap), Vector2(0, gap + line_length), color, line_width)
	draw_line(Vector2(-gap, 0), Vector2(-gap - line_length, 0), color, line_width)
	draw_line(Vector2(gap, 0), Vector2(gap + line_length, 0), color, line_width)

func _process(_delta: float) -> void:
	global_position = get_global_mouse_position()
